export default {
  aaa: function(){
    console.log("aaa");
  }
}